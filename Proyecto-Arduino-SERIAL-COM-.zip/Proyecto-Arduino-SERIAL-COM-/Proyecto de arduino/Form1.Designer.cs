﻿namespace Proyecto_de_arduino
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            button1 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            comboBox1 = new ComboBox();
            button2 = new Button();
            label6 = new Label();
            humedadAmbienteBox = new TextBox();
            label2 = new Label();
            temperaturaBox = new TextBox();
            label4 = new Label();
            label1 = new Label();
            label3 = new Label();
            label5 = new Label();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(647, 115);
            button1.Name = "button1";
            button1.Size = new Size(151, 29);
            button1.TabIndex = 0;
            button1.Text = "Conectar al Arduino";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // timer1
            // 
            timer1.Interval = 250;
            timer1.Tick += timer;
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(265, 117);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(202, 28);
            comboBox1.TabIndex = 2;
            comboBox1.Text = "Selecciona puerto COM";
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ActiveCaption;
            button2.FlatAppearance.BorderColor = Color.White;
            button2.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.ForeColor = SystemColors.ControlText;
            button2.Location = new Point(512, 115);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 4;
            button2.Text = "Refrescar puerto COM";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.BackColor = SystemColors.ActiveCaption;
            label6.Font = new Font("Segoe UI", 10.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.Location = new Point(34, 122);
            label6.Name = "label6";
            label6.Size = new Size(204, 23);
            label6.TabIndex = 15;
            label6.Text = "Seleccionar COM arduino";
            // 
            // humedadAmbienteBox
            // 
            humedadAmbienteBox.Location = new Point(338, 243);
            humedadAmbienteBox.Name = "humedadAmbienteBox";
            humedadAmbienteBox.Size = new Size(156, 27);
            humedadAmbienteBox.TabIndex = 5;
            humedadAmbienteBox.TextChanged += humedadAmbienteBox_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline | FontStyle.Strikeout, GraphicsUnit.Point, 0);
            label2.Location = new Point(314, 206);
            label2.Name = "label2";
            label2.Size = new Size(221, 23);
            label2.TabIndex = 7;
            label2.Text = "Sensor Humedad ambiente";
            // 
            // temperaturaBox
            // 
            temperaturaBox.Location = new Point(338, 311);
            temperaturaBox.Name = "temperaturaBox";
            temperaturaBox.Size = new Size(156, 27);
            temperaturaBox.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 10.2F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline | FontStyle.Strikeout, GraphicsUnit.Point, 0);
            label4.Location = new Point(323, 273);
            label4.Name = "label4";
            label4.Size = new Size(186, 23);
            label4.TabIndex = 11;
            label4.Text = "Sensor de temperatura";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(192, 192, 255);
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold | FontStyle.Italic | FontStyle.Strikeout, GraphicsUnit.Point, 0);
            label1.Location = new Point(255, 9);
            label1.Name = "label1";
            label1.Size = new Size(364, 28);
            label1.TabIndex = 16;
            label1.Text = "Bienvenido a nuestro sensor del clima!!";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = SystemColors.ActiveCaption;
            label3.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold | FontStyle.Italic | FontStyle.Strikeout, GraphicsUnit.Point, 0);
            label3.Location = new Point(295, 168);
            label3.Name = "label3";
            label3.Size = new Size(243, 25);
            label3.TabIndex = 17;
            label3.Text = "OPCIONES DEL PROGRAMA:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BackColor = SystemColors.ActiveCaption;
            label5.Font = new Font("Segoe UI Semibold", 10.8F, FontStyle.Bold | FontStyle.Italic | FontStyle.Underline | FontStyle.Strikeout, GraphicsUnit.Point, 0);
            label5.Location = new Point(314, 63);
            label5.Name = "label5";
            label5.Size = new Size(227, 25);
            label5.TabIndex = 18;
            label5.Text = "OPCIONES DE CONEXION:";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(837, 449);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(label6);
            Controls.Add(label4);
            Controls.Add(temperaturaBox);
            Controls.Add(label2);
            Controls.Add(humedadAmbienteBox);
            Controls.Add(button2);
            Controls.Add(comboBox1);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private System.Windows.Forms.Timer timer1;
        private ComboBox comboBox1;
        private Button button2;
        private Label label6;
        private TextBox humedadAmbienteBox;
        private Label label2;
        private TextBox temperaturaBox;
        private Label label4;
        private Label label1;
        private Label label3;
        private Label label5;
    }
}
