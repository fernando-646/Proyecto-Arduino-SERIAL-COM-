using System;
using System.Diagnostics;
using System.IO.Ports;
using System.Linq.Expressions;
using System.Management;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;
namespace Proyecto_de_arduino

{
    public partial class Form1 : Form
    {
        SerialPort puertoSerial = new SerialPort();
        //string humedadTierra, humedadGeneral, agua, temperatura;
        private DateTime ultimaRespuesta = DateTime.Now;
        private bool arduinoActivo = false, arduinoOcupado = false; // Para evitar m�ltiples mensajes
        string humedadTierra = null, humedadGeneral = null, agua = null, temperatura = null, estado = null, conexion = null;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text.Contains("Selecciona puerto COM"))
            {
                MessageBox.Show("No se ha seleccionado ningun puerto COM.", "Sin puerto COM", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            if (comboBox1.SelectedItem != null && !puertoSerial.IsOpen)
            {
                puertoSerial.PortName = ExtraerPuertoCOM(comboBox1.SelectedItem.ToString());
                puertoSerial.BaudRate = 9600; // Igual que en el Arduino
                if (!puertoSerial.IsOpen)
                {
                    try { puertoSerial.Open(); arduinoActivo = true; timer1.Enabled = true; }
                    catch (Exception serial)
                    {
                        MessageBox.Show("Error, el arduino se ha desconectado, porfavor intente de nuevo ");
                    }
                }
            }
        }
        private void timer(object sender, EventArgs e)
        {
            if (puertoSerial.IsOpen && comboBox1.SelectedItem != null)
            {
                try
                {
                    humedadAmbienteBox.Clear(); temperaturaBox.Clear();
                    Debug.Print("HOLA");
                    puertoSerial.Write("x");
                    string linea = puertoSerial.ReadLine();
                    ProcesarLinea(linea, ref humedadGeneral, ref temperatura, ref estado);

                    // Limpia y actualiza TextBoxes

                    humedadAmbienteBox.Text = humedadGeneral;
                    temperaturaBox.Text = temperatura + " �C";
                    //label7.Text = "";
                    //label7.Text = "Estado del arduino: " + estado;
                    arduinoActivo = true;
                }
                catch (IOException)
                {
                }
                catch (InvalidOperationException)
                {
                    MessageBox.Show("El puerto serial ya no est� disponible.", "Puerto cerrado", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {

            string[] puertos = SerialPort.GetPortNames();
            comboBox1.Items.Clear();
            comboBox1.Text = "Selecciona puerto COM";
            using (var searcher = new ManagementObjectSearcher("SELECT * FROM Win32_PnPEntity WHERE Name LIKE '%(COM%'"))
            {
                foreach (var device in searcher.Get())
                {
                    string nombre = device["Name"]?.ToString();
                    if (nombre != null && nombre.ToLower().Contains("usb"))
                    {
                        comboBox1.Items.Add(nombre);
                    }

                }
            }

        }
        public static string ExtraerPuertoCOM(string texto)
        {
            Match match = Regex.Match(texto, @"\bCOM\d+\b");
            return match.Success ? match.Value : null;
        }

        public static void ProcesarLinea(string linea, ref string humedadTierrax, ref string temperaturax, ref string estado)
        {
            var regex = new Regex(@"Sensor de (.+?):\s*(.+)");
            Match match = regex.Match(linea);

            if (match.Success)
            {
                //Debug.WriteLine("Hoal");
                string nombre = match.Groups[1].Value.Trim().ToLower();
                string valor = match.Groups[2].Value.Trim();
                //Debug.WriteLine(nombre);
                if (nombre.Equals("humedad general"))
                    humedadTierrax = valor;
                else if (nombre.Contains("temperatura"))
                    temperaturax = valor;
                else if (nombre.Contains("estado"))
                    estado = valor;
                Debug.Print(valor);

            }
        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void humedadAmbienteBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}